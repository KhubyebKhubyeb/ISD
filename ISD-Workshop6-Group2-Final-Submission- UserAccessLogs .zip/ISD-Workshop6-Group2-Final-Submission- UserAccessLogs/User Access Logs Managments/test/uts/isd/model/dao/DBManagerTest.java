/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.isd.model.dao;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import uts.isd.model.User;

/**
 *
 * @author naifmawlawi
 */
public class DBManagerTest {
    
    public DBManagerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getUserLogs method, of class DBManager.
     */
    @Test
    public void testGetUserLogs() throws Exception {
        System.out.println("getUserLogs");
        String userID = "";
        DBManager instance = null;
        List<User> expResult = null;
        List<User> result = instance.getUserLogs(userID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FindLogs method, of class DBManager.
     */
    @Test
    public void testFindLogs() throws Exception {
        System.out.println("FindLogs");
        String userID = "";
        String action = "";
        String date = "";
        DBManager instance = null;
        User expResult = null;
        User result = instance.FindLogs(userID, action, date);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteDate method, of class DBManager.
     */
    @Test
    public void testDeleteDate() throws Exception {
        System.out.println("deleteDate");
        String ID = "";
        String action = "";
        String date = "";
        DBManager instance = null;
        instance.deleteDate(ID, action,date);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addLogs method, of class DBManager.
     */
    @Test
    public void testAddLogs() throws Exception {
        System.out.println("addLogs");
        String ID = "";
        String action = "";
        String date = "";
        String time = "";
        DBManager instance = null;
        instance.addLogs(ID, action, date, time);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
